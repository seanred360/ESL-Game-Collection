var class_simple_camera_shake =
[
    [ "StartShake", "class_simple_camera_shake.html#a6730920ed4a235ea6024880826b02bea", null ],
    [ "shakeDuration", "class_simple_camera_shake.html#a90de7a1c805d351ea5d56f138e56b853", null ],
    [ "shakeMagnitude", "class_simple_camera_shake.html#a16b4559a3d8f9f6a70ca316396cc905c", null ]
];