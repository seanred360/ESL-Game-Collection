var class_deactivate_tutorial =
[
    [ "destroyTime", "class_deactivate_tutorial.html#a3bf0357165cf688d5242234d7eba2713", null ],
    [ "tutorialCavas", "class_deactivate_tutorial.html#a15a744ebd5f102cd96a4ff93cfdde7a4", null ]
];