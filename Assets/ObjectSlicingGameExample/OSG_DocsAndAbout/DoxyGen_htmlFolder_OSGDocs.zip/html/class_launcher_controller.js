var class_launcher_controller =
[
    [ "ReduceLaunchTimersAndLaunchObjects", "class_launcher_controller.html#a47b11e862a5462c2581224c0ece8a8e4", null ],
    [ "RequestBallSalvoFromBottom", "class_launcher_controller.html#af81051a2b58d6e7d054305205a718228", null ],
    [ "RequestBallSalvoFromSide", "class_launcher_controller.html#a9ce1ada16c95859bbf957ec3160c1b62", null ],
    [ "RequestBombSalvoFromBottomLauncher", "class_launcher_controller.html#a607d2d2c7164b69008a0241dccb2a3fb", null ],
    [ "BombSalvoAmount", "class_launcher_controller.html#abaf053efa494ced9383ddccd3215d7ab", null ],
    [ "bottomBallLaunchers", "class_launcher_controller.html#ab14d544001e48d4475849001bf19fc4f", null ],
    [ "bottomLauncherSalvoAmount", "class_launcher_controller.html#a747edf4ab65973512d6be5951d54b6d5", null ],
    [ "chillModeExtraBalls", "class_launcher_controller.html#a355d845749e2c01388a8c3aacce4176c", null ],
    [ "maxBombSalvoAmt", "class_launcher_controller.html#afe10ba5666dc28c05b13943228a62686", null ],
    [ "maximumSimultaneousBallLaunches", "class_launcher_controller.html#a9ce2ab932cdb2dd10f79b9d932083ab0", null ],
    [ "maxWaitTime", "class_launcher_controller.html#a6946faf3c6a98ff982960a5134c74097", null ],
    [ "minWaitTime", "class_launcher_controller.html#acf121f674d7ea05fba336fdcc7a96a05", null ],
    [ "resetBallLauncherAmount", "class_launcher_controller.html#a22036ba2babb6b38f2d8712197c57faf", null ],
    [ "sideBallLaunchers", "class_launcher_controller.html#a767584b8d12a560940fa19b4aea1f5fe", null ],
    [ "sideLauncherSalvoAmount", "class_launcher_controller.html#a31ecdd062013fc271224808e8a2c8ae9", null ],
    [ "timeBetweenBombLaunches", "class_launcher_controller.html#aecaaf17c34e2522eee8de5a32c52deee", null ],
    [ "timeBetweenLaunches", "class_launcher_controller.html#a27202c3a140190b3fee9e6cb726f28e0", null ],
    [ "timeBetweenRandomLaunches", "class_launcher_controller.html#a4e7cc831a194f9a082c7776f5fd945b2", null ]
];