var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "AnimationCurveMover", "class_animation_curve_mover.html", null ],
      [ "BallDestroyCombo", "class_ball_destroy_combo.html", null ],
      [ "BallLauncher", "class_ball_launcher.html", null ],
      [ "ChromaticAberration", "class_chromatic_aberration.html", null ],
      [ "CountdownTimer", "class_countdown_timer.html", null ],
      [ "DeactivateTutorial", "class_deactivate_tutorial.html", null ],
      [ "DestroyBall", "class_destroy_ball.html", null ],
      [ "DestroyBomb", "class_destroy_bomb.html", null ],
      [ "DestroyGameObject", "class_destroy_game_object.html", null ],
      [ "DisableGameObject", "class_disable_game_object.html", null ],
      [ "DojoBoundaryController", "class_dojo_boundary_controller.html", null ],
      [ "FaderCaller", "class_fader_caller.html", null ],
      [ "FaderReferenceSetup", "class_fader_reference_setup.html", null ],
      [ "GameController", "class_game_controller.html", null ],
      [ "GenericUIElementFade", "class_generic_u_i_element_fade.html", null ],
      [ "LauncherController", "class_launcher_controller.html", null ],
      [ "ObjectFollow", "class_object_follow.html", null ],
      [ "ObjectPoolScript", "class_object_pool_script.html", null ],
      [ "OSGTouchSlicer", "class_o_s_g_touch_slicer.html", null ],
      [ "RotateObject", "class_rotate_object.html", null ],
      [ "SelectDojoBackground", "class_select_dojo_background.html", null ],
      [ "SettingsAndPauseMenu", "class_settings_and_pause_menu.html", null ],
      [ "ShowCutBallUI", "class_show_cut_ball_u_i.html", null ],
      [ "SimpleCameraShake", "class_simple_camera_shake.html", null ],
      [ "Singleton< T >", "class_singleton.html", null ],
      [ "SplatterFade", "class_splatter_fade.html", null ],
      [ "TrailRendererHelper", "class_trail_renderer_helper.html", null ],
      [ "UIDojoSelector", "class_u_i_dojo_selector.html", null ]
    ] ],
    [ "Singleton< ScreenFaderSingleton >", "class_singleton.html", [
      [ "ScreenFaderSingleton", "class_screen_fader_singleton.html", null ]
    ] ]
];