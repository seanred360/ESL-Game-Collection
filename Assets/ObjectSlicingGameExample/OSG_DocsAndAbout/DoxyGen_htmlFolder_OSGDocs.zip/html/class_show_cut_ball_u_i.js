var class_show_cut_ball_u_i =
[
    [ "chillModeCutBallText", "class_show_cut_ball_u_i.html#a549cf05020644b70938fbd406fc39596", null ],
    [ "regularModeCutBallText", "class_show_cut_ball_u_i.html#a25da27fe98e5370db8b4522aea2ff275", null ]
];