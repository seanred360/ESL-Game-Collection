var searchData=
[
  ['redxheight',['redXHeight',['../class_dojo_boundary_controller.html#aeca4fed29261dce4a82810a06b4630ab',1,'DojoBoundaryController']]],
  ['redxregmode',['redXRegMode',['../class_game_controller.html#a4b213cd6d3c15461a963c5a23bbf114f',1,'GameController']]],
  ['regularmodecutballtext',['regularModeCutBallText',['../class_show_cut_ball_u_i.html#a25da27fe98e5370db8b4522aea2ff275',1,'ShowCutBallUI']]],
  ['regularmodehighesttext',['regularModeHighestText',['../class_game_controller.html#aaebd6c8879c0c65725b756fe5ca5d0aa',1,'GameController']]],
  ['regularmodetext',['regularModeText',['../class_game_controller.html#af5585a9cfe3063c86d874863b6c023b2',1,'GameController']]],
  ['resetballlauncheramount',['resetBallLauncherAmount',['../class_launcher_controller.html#a22036ba2babb6b38f2d8712197c57faf',1,'LauncherController']]],
  ['rotation',['rotation',['../class_rotate_object.html#ad853ad5d1214689eda566b187a67fec9',1,'RotateObject']]]
];
