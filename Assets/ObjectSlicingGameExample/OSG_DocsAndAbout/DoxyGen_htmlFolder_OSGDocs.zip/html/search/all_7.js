var searchData=
[
  ['ignoregametime',['ignoreGameTime',['../class_object_follow.html#aad250d149fee4d80c4079d33fb4db17b',1,'ObjectFollow.ignoreGameTime()'],['../class_settings_and_pause_menu.html#a07a5f5a8519987225f86c2f824fe4f11',1,'SettingsAndPauseMenu.ignoreGameTime()']]],
  ['ingamescene',['inGameScene',['../class_destroy_ball.html#ae0aea46082bf20bdc707c70c4b9cefb3',1,'DestroyBall']]],
  ['instance',['instance',['../class_select_dojo_background.html#a18957f704fc816e35988d78eb6cb07e1',1,'SelectDojoBackground.instance()'],['../class_settings_and_pause_menu.html#a94496a970d46a6aa6a8d3a37997c3fa5',1,'SettingsAndPauseMenu.instance()'],['../class_singleton.html#a54103e8475b2a352ee759d5732307534',1,'Singleton.Instance()']]]
];
