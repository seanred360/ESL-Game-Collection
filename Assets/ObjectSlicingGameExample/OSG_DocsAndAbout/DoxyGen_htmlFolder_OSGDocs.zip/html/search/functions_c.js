var searchData=
[
  ['takeballandendgame',['TakeBallAndEndGame',['../class_game_controller.html#a556f28ad9a20f9ee8a3cfce945e1585e',1,'GameController']]],
  ['thegameisdoneresetting',['TheGameIsDoneResetting',['../class_settings_and_pause_menu.html#a6cc845ed86b1674d07ac506f15073e52',1,'SettingsAndPauseMenu']]],
  ['thegameisresetting',['TheGameIsResetting',['../class_settings_and_pause_menu.html#aea082bf1c4fdfe8f5f5fb58b6a8b5ef9',1,'SettingsAndPauseMenu']]]
];
