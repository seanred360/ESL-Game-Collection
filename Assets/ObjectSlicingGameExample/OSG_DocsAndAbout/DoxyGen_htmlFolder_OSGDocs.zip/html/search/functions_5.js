var searchData=
[
  ['getpooledobject',['GetPooledObject',['../class_object_pool_script.html#a4992b8671e5348191e1c88691f168878',1,'ObjectPoolScript']]],
  ['getslicerdirection',['GetSlicerDirection',['../class_o_s_g_touch_slicer.html#a50f2b37f31b9d981f638e3c203a57387',1,'OSGTouchSlicer']]]
];
