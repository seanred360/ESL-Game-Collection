var class_countdown_timer =
[
    [ "DisableTimerText", "class_countdown_timer.html#afd76bf267d0081db8d3a4a0ec2d482f7", null ],
    [ "StartTimer", "class_countdown_timer.html#a33b40f15d66bef318a315f9607a9a2be", null ],
    [ "StopAndResetTimer", "class_countdown_timer.html#abb511cfa28fbde4efe93167c729f49c6", null ],
    [ "flashingColor", "class_countdown_timer.html#ab880a284c1a60be4cfd69f1b9131a2dd", null ],
    [ "startColor", "class_countdown_timer.html#a2812dfa82e13ff8d7afaa594b70fc3d7", null ],
    [ "timeBetweenTimerTextFlashes", "class_countdown_timer.html#a7fad0093b467a86a0c48a8816a63c46f", null ],
    [ "timeLeft", "class_countdown_timer.html#a343e676ea2ba2959c4b4bbd1aeec0f15", null ],
    [ "timeTextStartsFlashing", "class_countdown_timer.html#a5b68c6286bd62e038a20fcc4e1a6be9a", null ],
    [ "uiText", "class_countdown_timer.html#a1fe50ab5d0e475d95c07a85d58b58d2a", null ]
];