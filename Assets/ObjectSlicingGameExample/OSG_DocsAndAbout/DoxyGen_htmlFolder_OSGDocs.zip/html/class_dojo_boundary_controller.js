var class_dojo_boundary_controller =
[
    [ "OnTriggerEnter", "class_dojo_boundary_controller.html#a3d83cfde33a72c3ba6b4cc50fb8e5831", null ],
    [ "ballMissedX", "class_dojo_boundary_controller.html#ac1d925882c422a3082a0d911dc4687a4", null ],
    [ "redXHeight", "class_dojo_boundary_controller.html#aeca4fed29261dce4a82810a06b4630ab", null ]
];