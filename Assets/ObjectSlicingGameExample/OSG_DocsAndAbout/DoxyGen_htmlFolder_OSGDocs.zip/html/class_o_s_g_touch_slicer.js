var class_o_s_g_touch_slicer =
[
    [ "CheckSwipeOverlap", "class_o_s_g_touch_slicer.html#a25e62d000b1d4d348afe34428ec62cf0", null ],
    [ "GetSlicerDirection", "class_o_s_g_touch_slicer.html#a50f2b37f31b9d981f638e3c203a57387", null ],
    [ "OnTriggerEnter", "class_o_s_g_touch_slicer.html#add75c87caba80b74570f045629dc0290", null ],
    [ "emulateTouchesWithMouse", "class_o_s_g_touch_slicer.html#ad3877867305aff28b3be8b0f26f9b2cf", null ],
    [ "maxQueueSize", "class_o_s_g_touch_slicer.html#aa8dc8ba1a154d08a050e9a99f7539d4b", null ],
    [ "minimumSliceDistanceForAudio", "class_o_s_g_touch_slicer.html#a833a9f331281c904552436bcda451cf7", null ],
    [ "minimumTimeBetweenSwipes", "class_o_s_g_touch_slicer.html#a61c8ea727de21eafb47820d4c4581ebd", null ],
    [ "sliceableObjects", "class_o_s_g_touch_slicer.html#aa23c0e34a24b84b57404233032e1b261", null ],
    [ "swordSlashSounds", "class_o_s_g_touch_slicer.html#a2b2457313065cf8d5db5d03866cebf58", null ],
    [ "useColliderAndRaycast", "class_o_s_g_touch_slicer.html#a2c952ea4a7e7a19f1a4b3715cf23cdd9", null ]
];