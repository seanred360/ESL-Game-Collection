var class_game_controller =
[
    [ "TakeBallAndEndGame", "class_game_controller.html#a556f28ad9a20f9ee8a3cfce945e1585e", null ],
    [ "blueXRegMode", "class_game_controller.html#a2dbd24c0f759eaa1db41141150d2fd6e", null ],
    [ "chillModeHighestText", "class_game_controller.html#a88e985186e3c943e8e1b61251bcf1590", null ],
    [ "chillModeText", "class_game_controller.html#af4db4daab023784ad2cbcdda4981a372", null ],
    [ "gameIsRunning", "class_game_controller.html#a67341a4d883a1f963d3faa78bde03b3d", null ],
    [ "gameModes", "class_game_controller.html#a3cdcdaacf8064aee0ed3c9ca365c7984", null ],
    [ "gameOverPanel", "class_game_controller.html#a98b335505c99b20a67cf0e48bc2a1178", null ],
    [ "redXRegMode", "class_game_controller.html#a4b213cd6d3c15461a963c5a23bbf114f", null ],
    [ "regularModeHighestText", "class_game_controller.html#aaebd6c8879c0c65725b756fe5ca5d0aa", null ],
    [ "regularModeText", "class_game_controller.html#af5585a9cfe3063c86d874863b6c023b2", null ],
    [ "slicerGO", "class_game_controller.html#a03bf64be839a471d82f26e93d36c348a", null ],
    [ "waitForMenuAtEnd", "class_game_controller.html#a89d748ef9ce55cc399464319e307444a", null ]
];