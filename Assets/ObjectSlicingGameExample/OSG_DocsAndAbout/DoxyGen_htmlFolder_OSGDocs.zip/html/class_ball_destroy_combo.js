var class_ball_destroy_combo =
[
    [ "ActivateAndTweenComboText", "class_ball_destroy_combo.html#a79ad53de424534f244bf5814c3bbd78c", null ],
    [ "CheckTheCountdownTimer", "class_ball_destroy_combo.html#afc7fed26448ca3cffce545db9163ce8d", null ],
    [ "CheckTimeAndRecordBall", "class_ball_destroy_combo.html#a6342e2234fc6cbf10a801ee3e0108ed8", null ],
    [ "ChooseCorrectNumberSprite", "class_ball_destroy_combo.html#ab091ce7ae67f51d32a54f4f69676aaf0", null ],
    [ "DeactivateComboText", "class_ball_destroy_combo.html#a679395528ea1840c224feb20f7756a76", null ],
    [ "ResetComboTimer", "class_ball_destroy_combo.html#a98e74d13cf9eed7076ea6e4aa187bfb2", null ],
    [ "SetComboTextToBallPosition", "class_ball_destroy_combo.html#a181c56892fba9cb49cf6faf3c702451d", null ],
    [ "SortDistanceToComboTextAnchorLocation", "class_ball_destroy_combo.html#adfb475c7b46d87d827ef11e159fae389", null ],
    [ "ballComboNumImageReference", "class_ball_destroy_combo.html#ae682b2c8e17af9ef9534c01d4ea5d53a", null ],
    [ "ballsDestroyedInTime", "class_ball_destroy_combo.html#a449d22a6f3d547ae5ed5bdc898d7d365", null ],
    [ "comboAmountOfTime", "class_ball_destroy_combo.html#a3077e1e7d1f233d6dade4a7e85aa5020", null ],
    [ "comboNumberSpritesFromAtlas", "class_ball_destroy_combo.html#a60a568d10321cb383ddc6628481f8cd5", null ],
    [ "comboTextLocations", "class_ball_destroy_combo.html#acb3c20cb51a3daee4760c34b7d229117", null ],
    [ "selectedComboTextPoint", "class_ball_destroy_combo.html#a70b683cfba478e0d47429e8054762d87", null ],
    [ "useImagesForComboNum", "class_ball_destroy_combo.html#a97f0be0d86401a326e3c8fc485237512", null ]
];